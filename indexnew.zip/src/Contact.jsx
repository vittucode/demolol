import React from "react";
import {IoLocationOutline} from 'react-icons/io'

const Contact = () => {
   return <>
   <div className="container mx-auto flex justify-center items-center gap-20 mb-6 py-4 p-10  grid md:grid-cols-2 lg-grid-cols-3">
    <div>
        <h2 className="font-bold text-4xl">GET IN TOUCH WITH US</h2>
        <p className=" text-gray-500 py-12">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eius <br/> tempor incididunt ut labore et dolore magna aliqua.</p>
        <div>
         
            <div>
            <div><i class='bx bx-location-plus'></i>
            </div>
                <h1 className="font-bold text-2xl">Our Head Office</h1>
                <p>USD Services , Hadapsar , Pune ,<br/>  Maharashatra, India- 412308</p>
            </div>

            <div className="py-4">
                <img src="IoLocationOutline" alt="" />
            </div>
            <div>
                <h1 className="font-bold text-2xl">Call for Help</h1>
                <p>+91-7588223343</p>
            </div>

            <div className="py-4">
                <img src="IoLocationOutline" alt="" />
            </div>
            <div>
                <h1 className="font-bold text-2xl">Email for Information</h1>
                <p>usdservices@gmail.com</p>
            </div>
        </div>
    </div>
    <div className="border rounded-md shadow px-10 py-10 mb-6">
        <h2 className="border rounded-md py-4 px-4 mb-4 text-gray-400 ">Your Name</h2>
        <h2 className="border rounded-md py-4 px-4 mb-4 text-gray-400 ">your Number</h2>
        <h2 className="border rounded-md py-4 px-4 mb-4 text-gray-400 ">Your Email</h2>
        <h2 className="border rounded-md py-4 px-4 mb-4">--Select Service--</h2>
        <button className="bg-red-500 border rounded-md py-4 px-44  font-bold text-white">Send Message</button>

    </div>
   </div>
   
   </>
};

export default Contact