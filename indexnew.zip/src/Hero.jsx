import React from "react";

const Hero = () => {
    return (<>

        <div className="container mx-auto justify-between items-center flex  gap-4 h-full  py-4 p-10  grid md:grid-cols-2 lg-grid-cols-3  ">
            <div className=" px-12">
                <h2 className="bg-gray-200 rounded-md w-1/3 px-2 font-bold">BRAND NEW</h2>
                <h1 className="font-bold text-4xl py-2">Everything you <br />
                    can imagine is real</h1>
                <p className="text-gray-800 py-5 text-xl">Sed ut perspiciatis unde omnis iste natus error sit <br /> voluptatem accusantium doloremque laudantium, <br /> totam rem aperiam, eaque ipsa quae. explicabo.</p>
                <div className="">
                    <button className="bg-red-500 py-3 px-6 font-samibold text-white">Get started</button>
                    <button className="font-bold px-5">Learn more</button>
                </div>

            </div>
            <div className=" ">
                <img src="https://i0.wp.com/juntrax.com/blog/wp-content/uploads/2022/09/empsatisfaction.jpg?fit=940%2C788&ssl=1" alt="managment" />
            </div>
        </div>
        <div className="bg-purple-500">
            <div className="container mx-auto justify-center items-center py-10 flex gap-4 px-10  grid-cols-2 grid md:grid-cols-3 lg:grid-cols-4">
                <div className=" text-white font-bold border rounded-md ">
                    <div className="flex items-center py-2 px-6 ">
                        <img src="https://ik.imagekit.io/nboj7z3sl/WOrk_KKXdZU85E.png" alt="brifcase" />
                        <span className="py-20 px-2 text-3xl">13+</span>
                    </div>
                    <h2 className="text-center mb-10">Years in Business</h2>
                </div>

                <div className=" text-white font-bold border rounded-md ">
                    <div className="flex items-center py-2 px-6 ">
                        <img src="https://ik.imagekit.io/nboj7z3sl/happy_kyWqTo0Gz.png" alt="brifcase" />
                        <span className="py-20 px-2 text-3xl">300+</span>
                    </div>
                    <h2 className="text-center mb-10">Happy Clients</h2>
                </div>

                <div className=" text-white font-bold border rounded-md ">
                    <div className="flex items-center py-2 px-6 ">
                        <img src="https://ik.imagekit.io/nboj7z3sl/team_d1CnUPCwW.png" alt="brifcase" />
                        <span className="py-20 px-2 text-3xl">40+</span>
                    </div>
                    <h2 className="text-center mb-10">Technical Experts</h2>
                </div>

                <div className=" text-white font-bold border rounded-md ">
                    <div className="flex items-center py-2 px-6 ">
                        <img src="https://ik.imagekit.io/nboj7z3sl/satisfication_MqDtbjle4b.png" alt="brifcase" />
                        <span className="py-20 px-2 text-3xl ">130+</span>
                    </div>
                    <h2 className="text-center mb-10">Apps Delivered</h2>
                </div>
            </div>
        </div>

        <div className="justify-center text-center  py-10">
            <h2 className=" text-3xl">Our Services</h2>
            <p className="text-gray-700 py-5">USD Services offers a variety of IT consulting and Digital Marketing services which are flexible, robust & reliable as per our client’s <br /> requirements. At Vcana, we believe in building brands rather than a just a company or a name. Following is the list of services that <br /> we provide to our clients.</p>
        </div>
        <div className=" container mx-auto flex justify-center item-center gap-4 py-4 p-10 grid md:grid-cols-3  ">
            <div className="border rounded-md  shadow-md justify-centre text-center mx-5 py-10 px-10">
                <img className=" " src="https://www.q5infotech.com/wp-content/uploads/2020/09/Web-Development.jpeg" alt="" />
                <h2 className="font-bold  py-4 text-2xl">Web Development</h2>
                <p>website (also written as web site) is a collection of web pages and related content that is identified by a common domain name and published on at least one web server</p>
                <button className="bg-red-500 rounded-xl py-1 px-4 my-4">Learn More</button>
            </div>

            <div className="border rounded-md justify-centre text-center mx-5 py-10 px-10 shadow-md">
                <img className=" " src="https://norsecorp.com/wp-content/uploads/2020/02/fleet-scaled.jpg" alt="" />
                <h2 className="font-bold  py-4 text-2xl">Fleet Management</h2>
                <p>Fleet Management Companies Usa. ZapMeta Offers The Overview from 6 Engines.</p>
                <button className="bg-red-500 rounded-xl py-1 px-4 my-4">Learn More</button>
            </div>

            <div className="border rounded-md justify-centre text-center mx-5 py-10 px-10 shadow-md">
                <img className=" " src="https://www.cloudways.com/blog/wp-content/uploads/WordPress-Website-Hacked.jpg" alt="" />
                <h2 className="font-bold  py-4 text-2xl">Hack Site</h2>
                <p>In this tutorial you will learn how to hack websites, and we will introduce you to web application hacking techniques and the counter measures.</p>
                <button className="bg-red-500 rounded-xl py-1 px-4 my-4">Learn More</button>
            </div> 

            <div className="border rounded-md  shadow-md justify-centre text-center mx-5 py-10 px-10">
                <img className=" " src="https://www.blogtyrant.com/wp-content/uploads/2012/03/choose-best-blog-hosting.png" alt="" />
                <h2 className="font-bold  py-4 text-2xl">Host</h2>
                <p>GigaPromo is the website to compare Best Cloud Hosting Services. Search and save now! Find the lowest price for Best Cloud Hosting Services today!</p>
                <button className="bg-red-500 rounded-xl py-1 px-4 my-4">Learn More</button>
            </div>

            <div className="border rounded-md justify-centre text-center mx-5 py-10 px-10 shadow-md">
                <img className=" " src="https://aufaitux.com/wp-content/uploads/2020/05/UIUX-designing-1.jpg" alt="" />
                <h2 className="font-bold  py-4 text-2xl">Ui/UX Design</h2>
                <p>A user experience (UX) designer works on a team to create products the provide meaningful and enjoyable experiences for users.</p>
                <button className="bg-red-500 rounded-xl py-1 px-4 my-4">Learn More</button>
            </div>

            <div className="border rounded-md justify-centre text-center mx-5 py-10 px-10 shadow-md">
                <img className=" " src="https://limejuice.co.za/wp-content/uploads/2021/08/Lime-Juice-Website-Services-06.jpg" alt="" />
                <h2 className="font-bold  py-4 text-2xl">Green USD</h2>
                <p>Graphic design is the practice of composing and arranging the visual elements of a project. Designing the layout of a magazine, creating a poster for a theatre performance,</p>
                <button className="bg-red-500 rounded-xl py-1 px-4 my-4">Learn More</button>
            </div>

            <div className="border rounded-md justify-centre text-center mx-5 py-10 px-10 shadow-md">
                <img className=" " src="https://techtradigital.com/wp-content/uploads/2020/04/2020-google-Ideas-to-Increase-Business-Sale-Through-Digital-Marketing.jpg" alt="" />
                <h2 className="font-bold  py-4 text-2xl">Digital Marketing</h2>
                <p>At a high level, digital marketing refers to advertising delivered through digital channels such as search engines, websites, social media</p>
                <button className="bg-red-500 rounded-xl py-1 px-4 my-4">Learn More</button>
            </div>

            <div className="border rounded-md justify-centre text-center mx-5 py-10 px-10 shadow-md">
                <img className=" " src="https://www.w3care.com/images/uploads/services/logo-banner.png" alt="" />
                <h2 className="font-bold  py-4 text-2xl">Logo Design</h2>
                <p>Know your brand personality. You should have a clear idea of the brand personality you want to convey before you start designing a company logo</p>
                <button className="bg-red-500 rounded-xl py-1 px-4 my-4">Learn More</button>
            </div>




        </div>


    </>

    );
};

export default Hero
