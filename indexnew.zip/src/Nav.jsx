import React from 'react'
import {GrMenu} from 'react-icons/gr'
const Nav = () => {
    return (<>
        <div className='bg-white shadow-md'>
            <div className='container mx-auto flex justify-between items-center py-4 lg:px-14 md:px-8 px:6  '>
                <div className='w-28'>
                    <img className='' src="https://usd-service.vercel.app/static/media/Logo.a7213fc7e29b020ad256.png" alt="" />
                </div>
                <div className='flex gap-7 items-center md:flex hidden text-sm '>
                    <h2 className='hover:text-red-500'>HOME</h2>
                    <h2 className='hover:text-red-500'>ABOUT</h2>
                    <h2 className='hover:text-red-500'>SERVICE</h2>
                    <h2 className='hover:text-red-500'>OUR CLIENT</h2>
                    <h2 className='hover:text-red-500'>BLOG</h2>
                    <h2 className='hover:text-red-500'>CAREER</h2>

              
                </div>
                <div className='md:flex hidden'>
                    <button className='bg-red-500 text-white  py-1 px-5 rounded-md hover:bg-gray-800'>CONTACT US</button>
                </div>
               
                <div className='lg:hidden'>
                  <GrMenu/>  
                </div>
            </div>
        </div>

    </>
    )
}
export default Nav