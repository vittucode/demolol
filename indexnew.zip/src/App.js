
import Nav from "./Nav";
import Footer from "./Footer";
import Hero from "./Hero";
import About from "./About";
import Contact from "./Contact";


const App = () => {
  return (
  <>
       

       <Nav/>
       
       <Hero/>
       <About/>
       <Contact/>
       <Footer/>
       

  </>
  );
};

export default App;